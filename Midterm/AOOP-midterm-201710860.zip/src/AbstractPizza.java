public abstract class AbstractPizza {
    @Override
    public String toString() { return "Pizza Type: "; }

    public abstract double weight();
}

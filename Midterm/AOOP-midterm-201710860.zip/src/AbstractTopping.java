public abstract class AbstractTopping extends AbstractPizza{
    protected String topptingName;

    public AbstractTopping(String name) {
        topptingName = name;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
